library(shiny)
library(forcats)
library(ggplot2)
library(dplyr)

cdc <- read.csv("https://raw.githubusercontent.com/johnpannyc/Jun-Pan-DATA-608-Project-3/master/cleaned-cdc-mortality-1999-2010-2.csv")

#Define UI for application


ui <- fluidPage(    
  
  # Create a title for the panel
  titlePanel("Mortality Rates Across State in USA"),
  
  # Sidebar layout with input and output definitions
  sidebarLayout(      
    
    # Define input
    sidebarPanel(
      selectInput("cause", "Select a Cause:", 
                  sort(unique(cdc$ICD.Chapter))),
      
      helpText("year 2010")
    ),
    
    # Create Output
    mainPanel(
      plotOutput("Plot")  
    )
    
  )
)




#Define server function required to create the barplot.
server <- function(input, output){
  
  
  
  output$Plot <- renderPlot({
    
    cdc_data <- cdc %>% 
      filter(Year == 2010) %>% 
      filter(ICD.Chapter == input$cause) %>% 
      select(c(ICD.Chapter,State,Crude.Rate)) 
    
    
    
    cdc_data %>%
      mutate(State = fct_reorder(State, Crude.Rate)) %>%
      ggplot( aes(x=State, y=Crude.Rate,width=.5)) +
      geom_bar(stat="identity",position="identity") +
      geom_text(size = 5, aes(label = Crude.Rate), position = position_dodge(width = 1),
                inherit.aes = TRUE,
                hjust = -0.5) +
      coord_flip()}, height = 800, width = 750)
}
  





#Create the shiny app object
shinyApp(ui = ui, server = server) 


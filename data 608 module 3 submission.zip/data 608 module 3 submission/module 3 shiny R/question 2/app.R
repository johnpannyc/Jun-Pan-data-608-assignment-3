library(shiny)
library(ggplot2)
library(dplyr)
library(forcats)

cdc <-read.csv("https://raw.githubusercontent.com/johnpannyc/Jun-Pan-DATA-608-Project-3/master/cleaned-cdc-mortality-1999-2010-2.csv")

#Define UI  
ui <- fluidPage(    
  
  # Title of Panel
  titlePanel("Mortality Rate by Year: black line = national average"),
  
  # Sidebar Layout
  sidebarLayout(      
    
    # Define input
    sidebarPanel(
      selectInput("cause", "Select a Cause:", 
                  choices=as.character(unique(cdc$ICD.Chapter))),
      selectInput("state", "Select a State:", 
                  choices=as.character(unique(cdc$State)))
      
    ),
    
    # Define output
    mainPanel(
      plotOutput("Plot")  
    )
    
  )
)





#Define Server function to create bar plot
server <- function(input, output){
  
  
  
  output$Plot <- renderPlot({
    
    clean_data <- cdc %>% 
      filter(ICD.Chapter == input$cause) %>% 
      group_by(Year) %>%
      mutate(weight=(Population/sum(Population))*Crude.Rate) %>%
      mutate(avg=sum(weight)) %>%
      filter(State == input$state)
    
    
    
    
    clean_data %>%
      ggplot( aes(x=Year, y=Crude.Rate,width=.5)) +
      geom_bar(stat="identity",position="identity",fill="grey", alpha = 0.7) +
      geom_text(size = 5, aes(label = Crude.Rate), position = position_dodge(width = 1),
                inherit.aes = TRUE,
                hjust = 0.5) +
      geom_line(aes(x=Year, y=avg)) +
      theme(axis.text=element_text(size=10),
            axis.title=element_text(size=12))}, height = 800, width = 750) 
  
}



#Create a shiny app object  
shinyApp(ui = ui, server = server) 

